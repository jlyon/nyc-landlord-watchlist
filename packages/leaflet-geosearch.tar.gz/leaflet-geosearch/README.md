### Filepicker Smart Package for Meteor

#### Overview

Currently, this is a simple package that just helps insert the filepicker library into the project.

#### Install

First install Meteorite:
`npm install -g meteorite`

Second, add the filepicker.io smart package:
`mrt add filepicker`

#### Features

- Adds the filepicker tag into the project

#### Known Potential Improvements

- Should work offline by falling back to local uploads. Just not sure what kind of url to return.
- Should allow you to set your apikey somehow.
